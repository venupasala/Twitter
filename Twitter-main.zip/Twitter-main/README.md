#Twitter - The Social Media Platform
Developed a Web Application where you can connect with people share your thoughts and interact with messages known as “tweets”. Registered users can post, like, and retweet tweets, but unregistered users can only read them.

Youtube Link: 


FrontEnd: #html5 #css3 #javascript
BackEnd: #php
Web Framework: #bootstrap4
DataBase: #mysql

#Features :
1. Login & Register
2. Post Tweets
3. Like & Comment on Tweets
4. Follow & Unfollow users
5. Send Messages
6. Notification System
7. Mention User
8. Add Hashtag
9. Search User
10.Edit Profile

#twitter #clone #frontend #backend #database #fullstack #webapplication #coding #programming #yashgaur #developer #project #websitedesigner #websitedeveloper #html #css

# Twitter-clone
• Developed a platform where users can connect with people share thoughts and interact with messages.
• Built basic login and register functionality which collects data from users and stores in the database.
• Implemented 10+ features including Post, Like, Comment, Search, and all the other social media functionalities.
• Integrated XAMPP server and MySQL to store, retrieve, and manages data in the database.
